Outline is in .GTL layer

There is no .GTP layer

All files made in Eagle Light v.6.5.0 for linux
