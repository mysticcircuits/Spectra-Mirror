Outline is in .GTL layer

There is no .GBO layer

All files made in Eagle Light v.6.5.0 for linux
